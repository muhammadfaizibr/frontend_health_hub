import React from 'react'
import BrowseByCategories from '@/components/BrowseByCategories'
import SearchResults from '@/components/SearchResults'
import SearchDoctors from '@/components/SearchDoctors';
const page = () => {
  const results = [
    { name: 'Dr. John Doe', specialty: 'Cardiology', location: 'New York' },
    { name: 'Dr. Jane Smith', specialty: 'Dermatology', location: 'Los Angeles' },
    { name: 'Dr. Emily Johnson', specialty: 'Neurology', location: 'Chicago' },
    { name: 'Dr. Michael Brown', specialty: 'Pediatrics', location: 'Houston' },
    { name: 'Dr. Sarah Davis', specialty: 'Psychiatry', location: 'Phoenix' },
    { name: 'Dr. David Wilson', specialty: 'Oncology', location: 'Philadelphia' },
    { name: 'Dr. Laura Martinez', specialty: 'Gynecology', location: 'San Antonio' },
    { name: 'Dr. James Anderson', specialty: 'Orthopedics', location: 'San Diego' },
  ];
  return (
    <div className='flex flex-col gap-6'>
      <SearchDoctors />
        <BrowseByCategories />
        <SearchResults results={results} />
    </div>
  )
}

export default page