import PatientSidebar from '@/components/PatientSidebar'
import React from 'react'

const Layout = ({children}) => {
  return (
    <div className='flex h-screen bg-primary'>
      <aside>
        <PatientSidebar />
      </aside>
      
      <main className='flex-1 p-lg overflow-y-auto bg-surface rounded-2xl m-lg ml-0'>
        {children}
      </main>
    </div>
  )
}

export default Layout;