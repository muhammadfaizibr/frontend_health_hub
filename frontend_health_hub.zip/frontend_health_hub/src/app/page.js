'use client';
import { useState } from 'react';

export default function StyleGuide() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [theme, setTheme] = useState('dark');

  const toggleTheme = () => {
    const newTheme = theme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  return (
    <div className="p-4xl bg-primary min-h-screen">
      {/* Theme Toggle */}
      <div className="mb-4xl flex justify-end">
        <button
          className="button button-secondary"
          onClick={toggleTheme}
        >
          Toggle to {theme === 'dark' ? 'Light' : 'Dark'} Theme
        </button>
      </div>

      {/* Typography Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Typography</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-lg">
          <div>
            <h2 className="text-3xl font-bold mb-md">Headings</h2>
            <h1 className="text-4xl font-bold mb-sm">H1 Heading</h1>
            <h2 className="text-3xl font-bold mb-sm">H2 Heading</h2>
            <h3 className="text-2xl font-bold mb-sm">H3 Heading</h3>
            <h4 className="text-xl font-bold mb-sm">H4 Heading</h4>
            <h5 className="text-lg font-bold mb-sm">H5 Heading</h5>
            <h6 className="text-base font-bold mb-sm">H6 Heading</h6>
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-md">Text Sizes & Weights</h2>
            <p className="text-6xl font-extrabold mb-sm">6xl Extrabold</p>
            <p className="text-5xl font-bold mb-sm">5xl Bold</p>
            <p className="text-4xl font-semibold mb-sm">4xl Semibold</p>
            <p className="text-3xl font-medium mb-sm">3xl Medium</p>
            <p className="text-2xl font-normal mb-sm">2xl Normal</p>
            <p className="text-xl mb-sm">xl</p>
            <p className="text-lg mb-sm">lg</p>
            <p className="text-base mb-sm">base</p>
            <p className="text-sm mb-sm">sm</p>
            <p className="text-xs mb-sm">xs</p>
            <p className="text-2xs mb-sm">2xs</p>
          </div>
          <div>
            <h2 className="text-3xl font-bold mb-md">Text Colors</h2>
            <p className="text-primary mb-sm">Text Primary</p>
            <p className="text-secondary mb-sm">Text Secondary</p>
            <p className="text-tertiary mb-sm">Text Tertiary</p>
            <p className="text-inverse mb-sm">Text Inverse</p>
            <p className="text-success mb-sm">Text Success</p>
            <p className="text-error mb-sm">Text Error</p>
            <p className="text-warning mb-sm">Text Warning</p>
            <p className="text-info mb-sm">Text Info</p>
            <p className="text-accent mb-sm">Text Accent</p>
          </div>
        </div>
      </section>

      {/* Buttons Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Buttons</h1>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-lg">
          <button className="button button-primary">Primary Button</button>
          <button className="button button-secondary">Secondary Button</button>
          <button className="button button-emergency">
            <span className="material-symbols-outlined mr-sm">emergency</span>
            Emergency Button
          </button>
          <button className="button button-social">
            <span className="material-symbols-outlined mr-sm">google</span>
            Social Button
          </button>
          <button className="button button-primary button-disabled" disabled>
            Disabled Button
          </button>
        </div>
      </section>

      {/* Inputs Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Form Inputs</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-lg">
          <div className="relative">
            <span className="form-icon material-symbols-outlined">mail</span>
            <input
              className="form-input"
              type="email"
              placeholder="Email Address"
            />
          </div>
          <div className="relative">
            <span className="form-icon material-symbols-outlined">lock</span>
            <input
              className="form-input"
              type="password"
              placeholder="Password"
            />
          </div>
          <div className="relative">
            <span className="form-icon material-symbols-outlined">person</span>
            <input
              className="form-input"
              type="text"
              placeholder="Full Name (Disabled)"
              disabled
            />
          </div>
          <div>
            <p className="form-error mb-sm">Error message example</p>
            <p className="form-success">Success message example</p>
          </div>
        </div>
      </section>

      {/* Cards Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Cards</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-lg">
          <div className="card">
            <h2 className="text-2xl font-bold mb-sm">Card Title</h2>
            <p className="text-secondary mb-md">
              This is a sample card with some content.
            </p>
            <button className="button button-primary">Action</button>
          </div>
          <div className="card">
            <h2 className="text-2xl font-bold mb-sm">Card with Image</h2>
            <div
              className="h-40 rounded-md bg-cover bg-center mb-md"
              style={{ backgroundImage: 'url(https://via.placeholder.com/300)' }}
            />
            <p className="text-secondary">Card with background image.</p>
          </div>
        </div>
      </section>

      {/* Navigation Links Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Navigation Links</h1>
        <nav className="flex flex-col gap-sm max-w-xs">
          <a href="#" className="nav-link">
            <span className="material-symbols-outlined">home</span>
            Home
          </a>
          <a href="#" className="nav-link active">
            <span className="material-symbols-outlined">dashboard</span>
            Dashboard (Active)
          </a>
          <a href="#" className="nav-link">
            <span className="material-symbols-outlined">person</span>
            Profile
          </a>
        </nav>
      </section>

      {/* Modal Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Modal</h1>
        <button
          className="button button-primary mb-md"
          onClick={() => setIsModalOpen(true)}
        >
          Open Modal
        </button>
        {isModalOpen && (
          <>
            <div className="modal-backdrop" onClick={() => setIsModalOpen(false)} />
            <div className="modal fade-in">
              <h2 className="text-2xl font-bold mb-md">Modal Title</h2>
              <p className="text-secondary mb-md">
                This is a sample modal content. Click outside or the button below to close.
              </p>
              <button
                className="button button-secondary"
                onClick={() => setIsModalOpen(false)}
              >
                Close
              </button>
            </div>
          </>
        )}
      </section>

      {/* Tooltip Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Tooltip</h1>
        <div className="relative inline-block">
          <button className="button button-primary">Hover for Tooltip</button>
          <span className="tooltip bottom-10 left-1/2 -translate-x-1/2">
            This is a tooltip!
          </span>
        </div>
      </section>

      {/* Alerts Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Alerts</h1>
        <div className="flex flex-col gap-md max-w-md">
          <div className="alert alert-success">
            <span className="material-symbols-outlined">check_circle</span>
            Success alert message.
          </div>
          <div className="alert alert-error">
            <span className="material-symbols-outlined">error</span>
            Error alert message.
          </div>
          <div className="alert alert-warning">
            <span className="material-symbols-outlined">warning</span>
            Warning alert message.
          </div>
          <div className="alert alert-info">
            <span className="material-symbols-outlined">info</span>
            Info alert message.
          </div>
        </div>
      </section>

      {/* Layout Utilities Section */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Layout Utilities</h1>
        <div className="mb-lg">
          <h2 className="text-2xl font-bold mb-md">Flexbox</h2>
          <div className="flex items-center justify-between gap-md bg-surface p-md rounded-md">
            <div className="bg-primary-color text-inverse p-sm rounded-sm">Flex Item 1</div>
            <div className="bg-primary-color text-inverse p-sm rounded-sm">Flex Item 2</div>
            <div className="bg-primary-color text-inverse p-sm rounded-sm">Flex Item 3</div>
          </div>
        </div>
        <div>
          <h2 className="text-2xl font-bold mb-md">Grid</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-md">
            <div className="bg-surface p-md rounded-md text-center">Grid Item 1</div>
            <div className="bg-surface p-md rounded-md text-center">Grid Item 2</div>
            <div className="bg-surface p-md rounded-md text-center">Grid Item 3</div>
            <div className="bg-surface p-md rounded-md text-center">Grid Item 4</div>
          </div>
        </div>
      </section>

      {/* Loading Spinner */}
      <section className="mb-4xl">
        <h1 className="text-4xl font-bold mb-lg">Loading Spinner</h1>
        <div className="flex justify-center">
          <div className="spin h-8 w-8 border-4 border-primary-color border-t-transparent rounded-full" />
        </div>
      </section>
    </div>
  );
}