"use client";

import React from "react";
import Link from "next/link";
import { platformName } from "@/config/global";
import Button from "@/components/core/Button";
export const page = () => {
  const [isLoading, setIsLoading] = React.useState(false);

  const handleLogin = (e) => {
    setIsLoading(true);
    // Simulate a login process
    setTimeout(() => {
      setIsLoading(false);
      // Redirect or show success message here
    }, 2000);
    e.preventDefault();
  };

  return (
    <div className="flex justify-center flex-col items-center gap-8 h-screen px-4">
      <div className="absolute top-4 left-4">
        <Link href="/" className="text-primary hover:underline">
          &larr; Back to Home
        </Link>
      </div>
      <div className="flex justify-center flex-col items-center w-full p-8 gap-6">
        <div className="text-center flex flex-col gap-2">
          <h1 className="text-3xl font-bold">Welcome Back</h1>
          <p className="mt-4 text-secondary">
            Login to access your {platformName} account.
          </p>
        </div>
        <form
          className="mt-8 flex flex-col gap-4 w-full max-w-md mx-auto"
          onSubmit={handleLogin}
        >
          <div className="relative">
            <input
              type="text"
              placeholder="Username"
              className="form-input pl-12 w-full form-input-with-icon"
            />
            <span className="material-symbols-outlined form-icon">person</span>
          </div>

          <div className="relative">
            <input
              type="password"
              placeholder="Password"
              className="form-input pl-12 w-full form-input-with-icon"
            />
            <span className="material-symbols-outlined form-icon">lock</span>
          </div>

          <Link
            href="#"
            className="text-sm text-secondary hover:underline mb-4 text-right self-end"
          >
            Forgot Password?
          </Link>

          <Button
  variant="primary"
  size="md"
  type="submit"
  value={isLoading ? "Logging in..." : "Login"}
  isLoading={isLoading}
>
  Submit Form
</Button>
        </form>
      </div>
    </div>
  );
};

export default page;
