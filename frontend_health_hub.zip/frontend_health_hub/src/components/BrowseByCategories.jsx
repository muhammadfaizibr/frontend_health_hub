import React from 'react'
import CategoryCard from './CategoryCard';

const BrowseByCategories = () => {
    const categories = [
        { name: 'Cardiology', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Dermatology', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Neurology', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Pediatrics', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Psychiatry', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Oncology', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Gynecology', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
        { name: 'Orthopedics', image: 'https://images.unsplash.com/photo-1711409650645-a568a59446f0?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnJhaW4lMjB2ZWN0b3J8ZW58MHx8MHx8fDA%3D' },
    ];

    return (
        <section className="mb-xl">
            <h3 className='text-xl font-semibold mb-lg text-primary'>Browse by Categories</h3>
            <div className='flex gap-lg overflow-x-auto py-sm'>
                {categories.map((category, index) => (
                    <CategoryCard key={index} index={index} image={category.image} name={category.name} />
                ))}
            </div>
        </section>
    )
}

export default BrowseByCategories
