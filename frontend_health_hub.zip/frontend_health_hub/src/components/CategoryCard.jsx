import Link from 'next/link'
import React from 'react'
import Image from 'next/image'

const CategoryCard = ({index, image, name}) => {
  return (
    <Link href={`/search?category=${name}`} passHref>
      <div key={index} className='p-md rounded-lg bg-secondary text-center hover:text-primary-color transition-base cursor-pointer min-w-[200px] card'>
        <div className='w-24 h-24 relative mb-sm mx-auto bg-surface rounded-full'>
          <Image src={image} alt={name} fill className='object-contain rounded-lg'/>
        </div>  
        <span className="text-base font-medium">{name}</span>
      </div>
    </Link>
  )
}

export default CategoryCard
