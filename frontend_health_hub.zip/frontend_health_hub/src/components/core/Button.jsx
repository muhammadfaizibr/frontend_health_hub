import React from "react";
import { LoadingSpinner } from "@/components/core/LoadingSpinner";
import PropTypes from "prop-types";

export const Button = ({
  children,
  value,
  variant,
  size,
  fullWidth,
  type,
  isLoading,
  disabled,
  onClick,
  className,
  ...props
}) => {
  // Base button classes from your CSS
  const baseClasses = "button gap-2";
  
  // Variant classes based on your CSS
  const variantClasses = {
    primary: "button-primary",
    secondary: "button-secondary", 
    outline: "button-outline",
    ghost: "button-ghost",
    link: "button-link",
    emergency: "button-emergency",
    social: "button-social"
  };

  // Size classes based on your CSS
  const sizeClasses = {
    sm: "button-sm",
    md: "", // default size, no extra class needed
    lg: "button-lg", 
    xl: "button-xl"
  };

  // Build className string
  const buttonClasses = [
    baseClasses,
    variantClasses[variant],
    sizeClasses[size],
    fullWidth ? "w-full" : "",
    (isLoading || disabled) ? "button-disabled" : "",
    className || ""
  ].filter(Boolean).join(" ");

  const handleClick = (e) => {
    if (isLoading || disabled) {
      e.preventDefault();
      return;
    }
    if (onClick) {
      onClick(e);
    }
  };

  const buttonContent = value || children;

  return (
    <button
      type={type}
      className={buttonClasses}
      onClick={handleClick}
      disabled={isLoading || disabled}
      {...props}
    >
      {isLoading && <LoadingSpinner size="sm" />}
      {buttonContent}
    </button>
  );
};

Button.propTypes = {
  // Content props
  children: PropTypes.node,
  value: PropTypes.string,
  
  // Styling props
  variant: PropTypes.oneOf([
    "primary", 
    "secondary", 
    "outline", 
    "ghost", 
    "link", 
    "emergency", 
    "social"
  ]),
  size: PropTypes.oneOf(["sm", "md", "lg", "xl"]),
  fullWidth: PropTypes.bool,
  className: PropTypes.string,
  
  // Behavior props
  type: PropTypes.oneOf(["button", "submit", "reset"]),
  isLoading: PropTypes.bool,
  disabled: PropTypes.bool,
  onClick: PropTypes.func,
};

Button.defaultProps = {
  variant: "primary",
  size: "md", 
  fullWidth: false,
  type: "button",
  isLoading: false,
  disabled: false,
  onClick: null,
  className: "",
};

export default Button;