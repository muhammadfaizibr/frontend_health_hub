import React from 'react';

const sizeMap = {
  sm: 'h-4 w-4 border-2',
  md: 'h-8 w-8 border-4',
  lg: 'h-12 w-12 border-4',
  xl: 'h-16 w-16 border-8',
};

export const LoadingSpinner = ({ size = 'md', className = '' }) => {
  const spinnerSize = sizeMap[size] || sizeMap['md'];
  return (
    <div className={`flex justify-center ${className}`}>
      <div
        className={`spin ${spinnerSize} border-t-transparent rounded-full`}
      />
    </div>
  );
};
