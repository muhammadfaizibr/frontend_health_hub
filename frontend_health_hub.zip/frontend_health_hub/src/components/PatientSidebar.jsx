// PatientSidebar.jsx - Fixed CSS variable syntax and improved styling
"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";

const PatientSidebar = () => {
  const pathname = usePathname();
  const menuLink = [
    { name: "Find Doctor", href: "find-doctor", icon: "search" },
    { name: "Appointments", href: "appointments", icon: "event" },
    { name: "Medical Records", href: "medical-records", icon: "folder" },
    { name: "Prescriptions", href: "prescriptions", icon: "medication" },
    { name: "Messages", href: "messages", icon: "message" },
    { name: "Profile", href: "profile", icon: "person" },
  ];

  return (
    <div className="h-full py-lg px-sm flex flex-col items-center bg-surface border-r border-light">
      <div className="flex gap-sm items-center mb-xl">
        <div className="w-10 h-10 relative">
          <Image
            src="https://images.unsplash.com/photo-1756370382832-1c8fe9965d67?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw4fHx8ZW58MHx8fHx8"
            alt="Logo"
            fill
            className="object-cover rounded-full"
          />
        </div>
      </div>

      <nav className="flex flex-col items-center gap-sm">
        {menuLink.map((link, index) => {
          const current = pathname.split("/").filter(Boolean).pop();
          const target = link.href.split("/").filter(Boolean).pop();
          const isActive = current === target;
          
          return (
            <Link
              key={index}
              href={link.href}
              className={`nav-link w-full !p-2 justify-center rounded-lg transition-base ${
                isActive ? 'active bg-primary-alpha-10 text-primary-color' : 'text-secondary hover:bg-primary-alpha-10'
              }`}
              title={link.name}
            >
              <span className="material-symbols-outlined text-xl">{link.icon}</span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
};

export default PatientSidebar;