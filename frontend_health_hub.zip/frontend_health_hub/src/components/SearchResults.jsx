import React from 'react'
import DoctorCard from './DoctorCard'

const SearchResults = ({ results, isLoading = false }) => {
  if (isLoading) {
    return (
      <div className='flex flex-col gap-lg'>
        <h3 className='text-xl font-semibold text-primary'>Searching...</h3>
        <div className="flex justify-center p-xl">
          <div className="spinner" />
        </div>
      </div>
    );
  }

  if (!results || results.length === 0) {
    return (
      <div className='flex flex-col items-center justify-center p-2xl text-center bg-secondary rounded-lg'>
        <span className="material-symbols-outlined text-6xl text-tertiary mb-lg">
          search_off
        </span>
        <h3 className='text-xl font-semibold text-primary mb-sm'>No Results Found</h3>
        <p className="text-secondary">Try adjusting your search criteria or browse by categories above.</p>
      </div>
    );
  }

  return (
    <section className='flex flex-col gap-lg'>
      <h3 className='text-xl font-semibold text-primary'>
        Search Results ({results.length} doctor{results.length !== 1 ? 's' : ''} found)
      </h3>
      <div className="flex flex-col gap-md">
        {results.map((doctor, index) => (
          <DoctorCard key={`${doctor.name}-${index}`} doctor={doctor} index={index} />
        ))}
      </div>
    </section>
  )
}

export default SearchResults