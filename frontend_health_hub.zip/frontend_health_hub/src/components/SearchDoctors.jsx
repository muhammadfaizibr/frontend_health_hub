// SearchDoctors.jsx - Fixed CSS variable syntax and improved form layout
"use client";

import React, { useState } from "react";
import Button from "./core/Button";

const SearchDoctors = () => {
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  return (
    <div className="flex items-center justify-center w-full font-bold gap-xl flex-col bg-secondary py-2xl px-xl rounded-lg card">
      <h2 className="text-3xl text-primary">Find Your Doctor</h2>
      
      <div className="flex flex-col gap-lg w-full max-w-4xl">
        {/* Main search bar */}
        <div className="flex items-stretch gap-sm">
          <div className="relative flex-1">
            <span className="form-icon material-symbols-outlined">search</span>
            <input
              type="text"
              placeholder="Search by name, specialty, or location"
              className="form-input form-input-with-icon w-full"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <Button 
            value={isLoading ? "Searching..." : "Search"} 
            styles="button-primary px-xl"
            disabled={isLoading}
          />
        </div>

        {/* Filters */}
        <div className="flex gap-sm flex-wrap">
          <select className="form-input flex-1 min-w-[200px] form-select">
            <option value="">All Specialties</option>
            <option value="cardiology">Cardiology</option>
            <option value="dermatology">Dermatology</option>
            <option value="neurology">Neurology</option>
            <option value="pediatrics">Pediatrics</option>
            <option value="psychiatry">Psychiatry</option>
            <option value="radiology">Radiology</option>
            <option value="surgery">Surgery</option>
          </select>

          <select className="form-input flex-1 min-w-[200px] form-select">
            <option value="">All Locations</option>
            <option value="new-york">New York</option>
            <option value="los-angeles">Los Angeles</option>
            <option value="chicago">Chicago</option>
            <option value="houston">Houston</option>
            <option value="miami">Miami</option>
            <option value="san-francisco">San Francisco</option>
            <option value="seattle">Seattle</option>
          </select>
        </div>
      </div>
    </div>
  );
};

export default SearchDoctors;