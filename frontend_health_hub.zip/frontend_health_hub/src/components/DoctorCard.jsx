import React from "react";
import Image from "next/image";

const DoctorCard = ({ index, doctor }) => {
  return (
    <div
      key={index}
      className="p-lg bg-secondary hover:shadow-lg transition-slow flex items-center text-start rounded-lg justify-between card"
    >
      <div className="flex items-start gap-xl">
        <div className="w-28 h-28 flex-shrink-0 relative">
          <Image
            src="https://images.unsplash.com/photo-1756370382832-1c8fe9965d67?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxmZWF0dXJlZC1waG90b3MtZmVlZHw4fHx8ZW58MHx8fHx8"
            fill
            alt={doctor.name}
            className="rounded-full object-cover"
          />
        </div>
        <div className="text-left gap-sm flex flex-col">
          <div className="flex items-center gap-xs">
            <span className="material-symbols-outlined text-warning text-base">
              star
            </span>
            <span className="text-sm text-primary-color font-medium">4.9</span>
            <span className="text-secondary text-xs">(120 reviews)</span>
          </div>
          <div className="flex gap-sm items-center">
            <h4 className="text-lg font-semibold text-primary">{doctor.name}</h4>
            <span
              className="material-symbols-outlined text-primary-color"
              style={{ fontSize: "0.9rem" }}
            >
              verified
            </span>
          </div>
          <p className="text-sm text-secondary">{doctor.specialty}, {doctor.location}</p>
          <div className="text-sm text-secondary flex gap-sm items-center">
            <span className="material-symbols-outlined text-base text-primary-color">
              calendar_month
            </span>
            <span className="text-primary-color">{doctor.availiblity || "Next availability: Tomorrow, 9 AM"}</span>
          </div>
        </div>
      </div>
      <button className="button button-primary">
        Book Now
      </button>
    </div>
  );
};

export default DoctorCard;